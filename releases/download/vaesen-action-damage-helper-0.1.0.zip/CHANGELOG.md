# Changelog

## v0.1.0
- First public version: per‑turn action tracking + damage dialog with extra successes. Field mapping via settings.
