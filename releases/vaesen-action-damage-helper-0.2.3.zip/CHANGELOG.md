# Changelog

## v0.2.3
- NEW: NPC/Vaesen condition Items activation (system.active).
- I18N: English and Italian localization.
- FIX: Chat button under Push.
- CLEAN: removed long/short action buttons.
