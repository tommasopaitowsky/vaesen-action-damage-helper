# Changelog

## v0.2.3
- NEW: Support for Vaesen/NPC condition Items (`system.active`).
- FIX: "Apply Damage" button now appears neatly under Push button in chat.
- CLEAN: Removed long/short action tracking buttons (focus on damage handling).

## v0.2.2
- Added preliminary NPC condition handling.

## v0.2.0
- Stable release: PC conditions with Broken, NPC numeric fallback, cleaned UI.

## v0.1.x
- Initial experiments with action tracking and damage application.
