# Vaesen – Action & Damage Helper

Apply Damage helper for the Vaesen system in Foundry VTT.

### Features
- PC: ticks condition boxes and sets Broken when full.
- NPC/Vaesen: activates condition Items (system.active), then reduces numeric tracks or falls back to flags.
- Chat: localized "Apply Damage" button under Push.
